plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.cocoisq.bluebigfish"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.cocoisq.bluebigfish"
        minSdk = 23
        targetSdk = 35
        versionCode = 28
        versionName = "28.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
}
